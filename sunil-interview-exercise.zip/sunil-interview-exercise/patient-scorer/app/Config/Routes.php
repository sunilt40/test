<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->post('api/top-patients', 'Patients::getScoredPatients');
$route['patients/top_n/(:num)'] = 'patients/top_n/$1';
