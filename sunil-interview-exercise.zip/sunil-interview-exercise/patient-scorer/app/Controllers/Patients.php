<?php

namespace App\Controllers;

class Patient extends BaseController
{
    public function __construct() {
        parent::__construct();
        $this->load->model('Patient_model');
    }

    public function top_n($n) {
        $hospital_latitude = $this->input->get('latitude');
        $hospital_longitude = $this->input->get('longitude');

        if (!$hospital_latitude || !$hospital_longitude) {
            $this->output->set_status_header(400);
            echo json_encode(['error' => 'Latitude and longitude are required.']);
            return;
        }

        $top_patients = $this->Patient_model->get_top_n_patients($hospital_latitude, $hospital_longitude, $n);
        echo json_encode($top_patients);
    }
}