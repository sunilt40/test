<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patient_model extends CI_Model {

    private $file_path = 'path/to/your/patients.json';

    public function load_patients() {
        $patients = json_decode(file_get_contents($this->file_path), true);
        return $patients;
    }

    public function calculate_distance($patient, $hospital_latitude, $hospital_longitude) {
        $patient_latitude = floatval($patient['latitude']);
        $patient_longitude = floatval($patient['longitude']);
        return sqrt(
            pow(($patient_longitude - $hospital_longitude), 2) + 
            pow(($patient_latitude - $hospital_latitude), 2)
        );
    }

    public function calculate_score(&$patient, $hospital_latitude, $hospital_longitude) {
        $patient['distanceToClinic'] = $this->calculate_distance($patient, $hospital_latitude, $hospital_longitude);
        $score = (
            ($patient['age'] * 0.1) -
            ($patient['distanceToClinic'] * 0.1) +
            ($patient['acceptedOffers'] * 0.3) -
            ($patient['canceledOffers'] * 0.3) -
            ($patient['replyTime'] * 0.2)
        );
        $patient['score'] = $score;
    }

    public function normalize_scores($patients) {
        $scores = array_column($patients, 'score');
        $high_score = max($scores);
        $low_score = min($scores);

        foreach ($patients as &$patient) {
            $normalized_score = ((($patient['score'] - $low_score) / ($high_score - $low_score)) * 9) + 1;
            $patient['normalizedScore'] = $normalized_score;
        }

        return $patients;
    }

    public function get_top_n_patients($hospital_latitude, $hospital_longitude, $n) {
        $patients = $this->load_patients();
        $hospital_latitude = floatval($hospital_latitude);
        $hospital_longitude = floatval($hospital_longitude);

        foreach ($patients as &$patient) {
            $this->calculate_score($patient, $hospital_latitude, $hospital_longitude);
        }

        $patients = $this->normalize_scores($patients);
        usort($patients, function($a, $b) {
            return $b['normalizedScore'] <=> $a['normalizedScore'];
        });

        return array_slice($patients, 0, $n);
    }
}
